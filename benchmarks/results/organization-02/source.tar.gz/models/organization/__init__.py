"""Bounded graph-resident organization, learning and renewal model.

Host transitions are distinct from admitted native rewrites.
"""
from .system import System, fresh, inherit
from .observe import inspect, audit, functional

__all__ = ["System", "fresh", "inherit", "inspect", "audit", "functional"]
