use serde_json::{json, Value};
use std::io::Write;
use std::process::{Command, Stdio};
fn invoke(command: &str, input: &str) -> std::process::Output {
    let mut child = Command::new(env!("CARGO_BIN_EXE_cli"))
        .args([command, "-"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap();
    child
        .stdin
        .take()
        .unwrap()
        .write_all(input.as_bytes())
        .unwrap();
    child.wait_with_output().unwrap()
}
fn request() -> Value {
    json!({"states":["a","b"],"start":"a","transitions":[
    {"from":"a","action":0,"target":"b"},{"from":"b","action":1,"target":"a"}],"word":[0,1]})
}
#[test]
fn acquired_model_execution_exports_an_ordinary_verified_trace() {
    let output = invoke("model-run", &request().to_string());
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    let report: Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(report["projected"], json!(["a", "b", "a"]));
    assert_eq!(report["admitted_steps"], 2);
    assert!(invoke("trace-check", &report["trace"].to_string())
        .status
        .success());
    let mut damaged = report["trace"].clone();
    damaged["initial_sha256"] = json!("0".repeat(64));
    assert!(!invoke("trace-check", &damaged.to_string()).status.success());
}
#[test]
fn malformed_and_resource_limited_models_have_distinct_exit_codes() {
    for input in ["null".to_string(), "{".to_string(), "{}".to_string()] {
        assert_eq!(invoke("model-run", &input).status.code(), Some(2));
    }
    let mut r = request();
    r["word"] = json!([1]);
    assert_eq!(invoke("model-run", &r.to_string()).status.code(), Some(2));
    r = request();
    r["native_max_work"] = json!(0);
    assert_eq!(invoke("model-run", &r.to_string()).status.code(), Some(3));
    for value in [
        json!(-1),
        json!(1.5),
        json!("0"),
        json!(u64::MAX),
        Value::Null,
    ] {
        r["native_max_work"] = value;
        assert_eq!(invoke("model-run", &r.to_string()).status.code(), Some(2));
    }
}
#[test]
fn empty_words_and_maximum_supported_words_are_checked() {
    let mut r = json!({"states":["x"],"start":"x","transitions":[{"from":"x","action":0,"target":"x"}],"word":[]});
    for length in [0, 16] {
        r["word"] = json!(vec![0; length]);
        let out = invoke("model-run", &r.to_string());
        assert!(out.status.success());
        let report: Value = serde_json::from_slice(&out.stdout).unwrap();
        assert_eq!(report["admitted_steps"], length);
    }
    r["word"] = json!(vec![0; 17]);
    assert_eq!(invoke("model-run", &r.to_string()).status.code(), Some(2));
}
